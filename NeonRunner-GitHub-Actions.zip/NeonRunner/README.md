# Neon Runner — Android + GitHub Actions

This project wraps the Neon Runner HTML game in an Android WebView.

## Build the APK with GitHub Actions

1. Create a GitHub repository and upload all files from this folder.
2. Keep the workflow at `.github/workflows/build-apk.yml`.
3. Push the project to the `main` branch, or open the repository's **Actions** tab and run **Build Neon Runner APK** manually.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the artifact named **NeonRunner-debug-apk**.
6. Extract the downloaded ZIP. The APK inside is `app-debug.apk`.

The workflow uses Java 17, Gradle 8.7 and Android Gradle Plugin 8.5.2.

## Project structure

- `app/src/main/assets/index.html` — the game
- `app/src/main/java/com/luiz/neonrunner/MainActivity.java` — Android WebView wrapper
- `.github/workflows/build-apk.yml` — automatic APK build
